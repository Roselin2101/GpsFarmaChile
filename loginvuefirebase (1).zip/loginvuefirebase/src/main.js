import Vue from 'vue'
import App from './App.vue'
import router from './router'
import * as firebase from 'firebase';

import 'bootstrap/dist/css/bootstrap.min.css'
import '@/assets/css/main.css'

Vue.config.productionTip = false

const firebaseConfig = {
  apiKey: "AIzaSyBWpg9oHY2SuUIpmOeoK8ieFjuBf0Io3R0",
  authDomain: "democontacform.firebaseapp.com",
  databaseURL: "https://democontacform-default-rtdb.firebaseio.com",
  projectId: "democontacform",
  storageBucket: "democontacform.appspot.com",
  messagingSenderId: "288006703495",
  appId: "1:288006703495:web:e285b9f3f39522ebdfeb22"
}

firebase.initializeApp(firebaseConfig);

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
